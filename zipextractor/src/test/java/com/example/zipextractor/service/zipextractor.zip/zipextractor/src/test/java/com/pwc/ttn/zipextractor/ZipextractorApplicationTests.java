package com.pwc.ttn.zipextractor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipextractorApplicationTests {

	@Test
	void contextLoads() {
	}

}
