package com.pwc.ttn.zipextractor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZipextractorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZipextractorApplication.class, args);
	}

}
